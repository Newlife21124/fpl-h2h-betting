# Stats Count (Railway One-Click)

A minimal Node.js/Express app scaffold for your H2H betting project with:
- Admin panel at `/admin` (edit API keys at runtime)
- 5% fee (via `FEE_PERCENT` env var)
- Postgres on Railway (automatically wired via `DATABASE_URL`)
- Works without keys until you add them

## Default Admin
- **Username:** admin
- **Password:** newlife21124
> Change via env vars `ADMIN_USERNAME` and `ADMIN_PASSWORD` on Railway.

## Deploy on Railway (with Postgres plugin)
Use this template link (paste in "Deploy a template" on Railway):

```
https://railway.app/template/3h2k1m?plugins=postgresql&envs=BETTING_API_KEY,FPL_API_KEY,FEE_PERCENT,ADMIN_PASSWORD&BETTING_API_KEYDefault=&FPL_API_KEYDefault=&FEE_PERCENTDefault=5&ADMIN_PASSWORDDesc=Password+for+/admin&referralCode=statscount
```

After deploy, open `/admin` to paste your real API keys.

## API Endpoints

- `GET /wallets/:userId` → Fetch wallet (auto-creates with 100 demo credits on first touch).
- `POST /admin/wallets/topup` (admin) → JSON: `{ "user_id": "u1", "amount": 50 }` to add funds.
- `POST /bets` → JSON: `{ "user_id": "u1", "match_id": "12345", "stake": 10 }`
  - Immediately deducts full stake from wallet.
  - Takes **5%** fee (`FEE_PERCENT`) at placement.
  - Stores bet with `stake`, `fee`, `net_stake` in DB.
- `GET /bets/:id` → Fetch a specific bet.

> Note: Replace demo credits and add real payment provider later. Fee percent configurable via `FEE_PERCENT` env var.

### Matches & Settlement

- `GET /matches` → Returns `{ mode: 'live'|'demo', matches: [...] }`. Live when keys present; demo otherwise.
- `POST /bets/settle` (admin) → JSON: `{ "bet_id": 1, "outcome": "win"|"lose", "odds": 1.9 }`
  - On `win`, credits wallet with `net_stake * odds` (defaults to `2.0` if not supplied).
  - Marks bet as `settled` and stores `outcome` and `payout`.

**Live data sources (when keys are set):**
- Fixtures: API-Football via RapidAPI (`FPL_API_KEY`).
- Odds: TheOddsAPI (`BETTING_API_KEY`).
