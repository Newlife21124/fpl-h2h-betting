import express from 'express';
import bodyParser from 'body-parser';
import session from 'express-session';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import pkg from 'pg';

dotenv.config();

const { Pool } = pkg;

const app = express();
const PORT = process.env.PORT || 10000;

// --- Session (Memory store is fine for Railway free tier) ---
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'statscount-secret',
  resave: false,
  saveUninitialized: false
}));

// --- Database ---
const dbUrl = process.env.DATABASE_URL;
let pool = null;
if (dbUrl) {
  pool = new Pool({ connectionString: dbUrl, ssl: dbUrl.includes('neon.tech') ? { rejectUnauthorized: false } : undefined });
}

// --- Extended schema for wallets and bets ---
async function ensureTables() {
  if (!pool) return;
  await pool.query(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );
    CREATE TABLE IF NOT EXISTS wallets (
      user_id TEXT PRIMARY KEY,
      balance NUMERIC NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS bets (
  id SERIAL PRIMARY KEY,
  user_id TEXT NOT NULL,
  match_id TEXT NOT NULL,
  stake NUMERIC NOT NULL,
  fee NUMERIC NOT NULL,
  net_stake NUMERIC NOT NULL,
  odds NUMERIC,
  payout NUMERIC,
  outcome TEXT, -- 'win' | 'lose' | null
  status TEXT NOT NULL DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
  `);
}

// --- Wallet helpers ---
async function getWallet(userId) {
  if (!pool) return { user_id: userId, balance: 0 };
  const { rows } = await pool.query('SELECT user_id, balance FROM wallets WHERE user_id=$1', [userId]);
  if (rows.length) return rows[0];
  // create with 100 demo credits on first-touch
  await pool.query('INSERT INTO wallets(user_id, balance) VALUES($1, 100)', [userId]);
  return { user_id: userId, balance: 100 };
}

async function setWalletBalance(userId, balance) {
  if (!pool) return;
  await pool.query(`
    INSERT INTO wallets(user_id, balance)
    VALUES($1, $2)
    ON CONFLICT (user_id) DO UPDATE SET balance = EXCLUDED.balance
  `, [userId, balance]);
}

// --- Public API: get wallet ---
app.get('/wallets/:userId', async (req, res) => {
  try {
    const w = await getWallet(req.params.userId);
    res.json(w);
  } catch (e) {
    res.status(500).json({ error: 'wallet_fetch_failed', details: e.message });
  }
});

// --- Admin: credit/debit wallet ---
app.post('/admin/wallets/topup', requireAdmin, async (req, res) => {
  try {
    const { user_id, amount } = req.body;
    if (!user_id || isNaN(parseFloat(amount))) return res.status(400).json({ error: 'invalid_params' });
    const w = await getWallet(user_id);
    const newBal = parseFloat(w.balance) + parseFloat(amount);
    await setWalletBalance(user_id, newBal);
    res.json({ ok: true, user_id, balance: newBal });
  } catch (e) {
    res.status(500).json({ error: 'wallet_topup_failed', details: e.message });
  }
});

// --- Place bet: deduct fee immediately ---
app.post('/bets', async (req, res) => {
  try {
    const { user_id, match_id, stake } = req.body;
    if (!user_id || !match_id || isNaN(parseFloat(stake)) || parseFloat(stake) <= 0) {
      return res.status(400).json({ error: 'invalid_params' });
    }
    const w = await getWallet(user_id);
    const stakeNum = parseFloat(stake);
    if (parseFloat(w.balance) < stakeNum) {
      return res.status(400).json({ error: 'insufficient_balance', balance: w.balance });
    }
    const fee = (FEE_PERCENT / 100) * stakeNum;
    const net = stakeNum - fee;

    // deduct full stake from wallet now
    const newBal = parseFloat(w.balance) - stakeNum;
    await setWalletBalance(user_id, newBal);

    let betId = null;
    if (pool) {
      const { rows } = await pool.query(
        'INSERT INTO bets(user_id, match_id, stake, fee, net_stake) VALUES($1,$2,$3,$4,$5) RETURNING id',
        [user_id, match_id, stakeNum, fee, net]
      );
      betId = rows[0].id;
    }

    res.json({
      ok: true,
      bet_id: betId,
      user_id,
      match_id,
      stake: stakeNum,
      fee_taken: fee,
      net_stake: net,
      fee_percent: FEE_PERCENT,
      wallet_balance: newBal
    });
  } catch (e) {
    res.status(500).json({ error: 'bet_place_failed', details: e.message });
  }
});

// --- Get bet by id ---
app.get('/bets/:id', async (req, res) => {
  try {
    if (!pool) return res.status(503).json({ error: 'db_required' });
    const { rows } = await pool.query('SELECT * FROM bets WHERE id=$1', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'not_found' });
    res.json(rows[0]);
  } catch (e) {
    res.status(500).json({ error: 'bet_fetch_failed', details: e.message });
  }
});

async function getSetting(key, defaultValue='') {
  if (!pool) return process.env[key] || defaultValue;
  const { rows } = await pool.query('SELECT value FROM settings WHERE key=$1', [key]);
  if (rows.length) return rows[0].value;
  return process.env[key] || defaultValue;
}

async function setSetting(key, value) {
  if (!pool) {
    // no DB yet, just set in-memory fallback
    process.env[key] = value;
    return;
  }
  await pool.query(`
    INSERT INTO settings(key, value)
    VALUES($1, $2)
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value
  `, [key, value]);
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.authed) return next();
  res.redirect('/login');
}

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'newlife21124'; // change in env after deploy
const FEE_PERCENT = parseFloat(process.env.FEE_PERCENT || '5');

// --- Views (simple inline HTML) ---
function layout(title, body) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${title}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/milligram/1.4.1/milligram.min.css">
<style>
  body { margin: 2rem; }
  .container { max-width: 800px; margin: 0 auto; }
  .card { border: 1px solid #eee; border-radius: 12px; padding: 1.25rem; box-shadow: 0 2px 10px rgba(0,0,0,0.04); }
  .muted { color: #666; font-size: 0.9rem; }
  .badge { padding: 0.2rem 0.6rem; border-radius: 999px; background: #f4f4f4; }
</style>
</head>
<body>
<div class="container">
${body}
</div>
</body>
</html>`;
}

// --- Routes ---
app.get('/', async (req, res) => {
  const bettingKey = await getSetting('BETTING_API_KEY', '');
  const fplKey = await getSetting('FPL_API_KEY', '');
  const hasKeys = Boolean(bettingKey) && Boolean(fplKey);
  const content = `
    <h2>Stats Count</h2>
    <div class="card">
      <p>Status: ${hasKeys ? '<span class="badge">Live Data</span>' : '<span class="badge">Demo Mode</span>'}</p>
      <p>Fee: <strong>${FEE_PERCENT}%</strong> per bet (deducted on placement).</p>
      <p class="muted">Go to <code>/admin</code> to configure API keys.</p>
      <a class="button" href="/admin">Open Admin</a>
    </div>
  `;
  res.send(layout('Stats Count', content));
});

app.get('/login', (req, res) => {
  const content = `
    <h3>Admin Login</h3>
    <form method="POST" action="/login" class="card">
      <label>Username</label>
      <input name="username" placeholder="admin" required/>
      <label>Password</label>
      <input name="password" type="password" required/>
      <button type="submit">Login</button>
      <p class="muted">Default: admin / newlife21124 (change via env vars)</p>
    </form>
  `;
  res.send(layout('Login', content));
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    req.session.authed = true;
    res.redirect('/admin');
  } else {
    res.status(401).send(layout('Login failed', `<p>Invalid credentials.</p><p><a href="/login">Try again</a></p>`));
  }
});

app.get('/admin', requireAdmin, async (req, res) => {
  const bettingKey = await getSetting('BETTING_API_KEY', '');
  const fplKey = await getSetting('FPL_API_KEY', '');
  const content = `
    <h3>Admin – API Keys</h3>
    <form method="POST" action="/admin/save" class="card">
      <label>Betting API Key</label>
      <input name="BETTING_API_KEY" value="${bettingKey || ''}" placeholder="Paste your Betting API key"/>
      <label>FPL API Key</label>
      <input name="FPL_API_KEY" value="${fplKey || ''}" placeholder="Paste your FPL/RapidAPI key"/>
      <button type="submit">Save</button>
    </form>
    <p><a href="/admin/test">Test Data Fetch</a></p>
  `;
  res.send(layout('Admin', content));
});

app.post('/admin/save', requireAdmin, async (req, res) => {
  const { BETTING_API_KEY, FPL_API_KEY } = req.body;
  await setSetting('BETTING_API_KEY', BETTING_API_KEY || '');
  await setSetting('FPL_API_KEY', FPL_API_KEY || '');
  res.send(layout('Saved', `<p>Saved keys.</p><p><a href="/admin">Back</a></p>`));
});

// Example test route that checks if keys exist (no external calls to avoid quota on first run)
app.get('/admin/test', requireAdmin, async (req, res) => {
  const bettingKey = await getSetting('BETTING_API_KEY', '');
  const fplKey = await getSetting('FPL_API_KEY', '');
  res.send(layout('Test', `
    <div class="card">
      <p>Betting Key: ${bettingKey ? '✅ Present' : '❌ Missing'}</p>
      <p>FPL Key: ${fplKey ? '✅ Present' : '❌ Missing'}</p>
      <p>You're good to go. Wire your fetchers to these settings in your data jobs.</p>
    </div>
  `));
});

// Health check
app.get('/healthz', (_req, res) => res.json({ ok: true }));

// Start
ensureTables().then(() => {
  app.listen(PORT, () => {
    console.log(`Stats Count listening on ${PORT}`);
  });
}).catch(err => {
  console.error('Failed to init DB', err);
  app.listen(PORT, () => console.log(`Stats Count (no DB) on ${PORT}`));
});


// --- Demo matches (used if no API keys) ---
const DEMO_MATCHES = [
  { id: 'EPL-001', league: 'Premier League', home: 'Arsenal', away: 'Chelsea', kickoff: '2025-08-20T15:00:00Z' },
  { id: 'EPL-002', league: 'Premier League', home: 'Man City', away: 'Liverpool', kickoff: '2025-08-21T17:30:00Z' },
  { id: 'SER-003', league: 'Serie A', home: 'Inter', away: 'Juventus', kickoff: '2025-08-22T19:45:00Z' },
];

// --- Matches endpoint ---
app.get('/matches', async (req, res) => {
  try {
    const bettingKey = process.env.BETTING_API_KEY || '';
    const fplKey = process.env.FPL_API_KEY || '';

    if (!bettingKey || !fplKey) {
      return res.json({ mode: 'demo', matches: DEMO_MATCHES });
    }

    // Example fetch from real APIs (replace with actual API calls)
    // const matches = await fetchLiveMatches(bettingKey, fplKey);
    const matches = DEMO_MATCHES; // fallback until integrated

    res.json({ mode: 'live', matches });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch matches', details: err.message });
  }
});

// --- Admin settle endpoint ---
app.post('/bets/settle', async (req, res) => {
  try {
    const adminKey = req.headers['x-admin-key'];
    if (adminKey !== process.env.ADMIN_KEY) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const { betId, outcome } = req.body;
    if (!betId || !['win', 'lose', 'draw'].includes(outcome)) {
      return res.status(400).json({ error: 'Invalid request' });
    }

    // TODO: Replace with DB update logic
    res.json({ message: `Bet ${betId} settled as ${outcome}` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to settle bet', details: err.message });
  }
});
